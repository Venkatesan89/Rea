import React from 'react'

const Header =()=>{
    return(
        <nav>
        <h3>Sowndharya</h3>
         <div class="navigation">
            <ul>
               <li><a href="Home">Home</a></li>
                <li><a href="About">About</a></li>
                <li><a href="Contact">Contact</a></li>
 </ul>

</div>
    </nav> 


       

    )


}
export default Header